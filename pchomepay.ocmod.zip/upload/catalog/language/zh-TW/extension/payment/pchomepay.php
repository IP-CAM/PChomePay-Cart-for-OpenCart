<?php
/**
 * Created by PhpStorm.
 * User: Jerry
 * Date: 2017/11/27
 * Time: 下午3:01
 */

// Text
$_['pchomepay_text_title']	= 'PChomePay支付連';
$_['pchomepay_text_testmode']	= '警告: 您現在使用的是Sandbox模式，帳戶不會實際扣款。';
$_['pchomepay_text_total']	= 'Shipping, Handling, Discounts & Taxes';

$_['pchomepay_text_card'] = '信用卡';
$_['pchomepay_text_atm'] = 'ATM';
$_['pchomepay_text_each'] = '銀行支付';
$_['pchomepay_text_acct'] = '支付連餘額付款';
$_['pchomepay_text_pi'] = 'Pi付款';
$_['pchomepay_text_ipl7'] = '7-11取貨付款';
$_['pchomepay_text_card_0'] = '一次付清';
$_['pchomepay_text_card_3'] = '3 期';
$_['pchomepay_text_card_6'] = '6 期';
$_['pchomepay_text_card_12'] = '12 期';
$_['pchomepay_text_checkout_button'] = '結帳';

$_['pchomepay_entry_payment_method'] = '付款方式';
